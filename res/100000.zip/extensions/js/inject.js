var $CONFIG = {tn:'48021271_19_hao_pg'};
